# Function that reads in the data
#' @export
ReadingIn <- function(x) { #myFunction is name of function, x is input of function -> use value of x here in function(3), then x = 3
  if (!is.matrix(x)) {
    stop('The input should be a matrix of shape ERP signal x time!')
  } #Insert code to be carried out when calling the function
}

# print error if not in the right format
